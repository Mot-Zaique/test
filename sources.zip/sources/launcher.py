import tkinter as tk
from tkinter import messagebox, simpledialog, scrolledtext
import os
import asyncio
import threading
import subprocess
import platform
from dotenv import load_dotenv
from bot import create_bot_instance, bot_instance

load_dotenv('token.env')
TOKEN: str = os.getenv("TOKEN")

class BotLauncher(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("KairosCord Launcher")
        self.geometry("600x800")
        self.token = os.getenv('TOKEN')
        self.bot = None

        self.token_label = tk.Label(self, text="Token actuel :")
        self.token_label.pack(pady=5)

        self.token_entry = tk.Entry(self, width=50)
        self.token_entry.pack(pady=5)
        self.token_entry.insert(0, self.token)

        self.save_button = tk.Button(self, text="Enregistrer le Token", command=self.save_token)
        self.save_button.pack(pady=5)

        self.extensions_label = tk.Label(self, text="Extensions trouvées :")
        self.extensions_label.pack(pady=5)

        self.extensions_list = tk.Listbox(self, width=50)
        self.extensions_list.pack(pady=5)
        self.load_extensions()

        self.open_extensions_button = tk.Button(self, text="Ouvrir le dossier Extensions", command=self.open_extensions_directory)
        self.open_extensions_button.pack(pady=5)

        self.start_button = tk.Button(self, text="Démarrer le Bot", command=self.start_bot)
        self.start_button.pack(pady=5)

        self.stop_button = tk.Button(self, text="Arrêter le Bot", command=self.stop_bot, state="disabled")
        self.stop_button.pack(pady=5)

        self.console_label = tk.Label(self, text="Console du Bot :")
        self.console_label.pack(pady=5)

        self.console_output = scrolledtext.ScrolledText(self, width=70, height=10, state='disabled', bg='black', fg='white')
        self.console_output.pack(pady=5)

        self.help_button = tk.Button(self, text="Aide", command=self.show_help)
        self.help_button.pack(pady=5)

        self.protocol("WM_DELETE_WINDOW", self.on_close)

        self._redirect_stdout()

    def _redirect_stdout(self):
        import sys
        class ConsoleRedirector:
            def __init__(self, text_widget):
                self.text_widget = text_widget

            def write(self, message):
                self.text_widget.configure(state='normal')
                self.text_widget.insert(tk.END, message)
                self.text_widget.see(tk.END)
                self.text_widget.configure(state='disabled')

            def flush(self):
                pass

        sys.stdout = ConsoleRedirector(self.console_output)
        sys.stderr = ConsoleRedirector(self.console_output)

    def load_extensions(self):
        if os.path.exists('extensions'):
            self.extensions_list.delete(0, tk.END)
            for filename in os.listdir('extensions'):
                if filename.endswith('.py'):
                    self.extensions_list.insert(tk.END, filename)
        else:
            self.extensions_list.insert(tk.END, "Aucun dossier 'extensions' trouvé.")

    @staticmethod
    def open_extensions_directory():
        path = os.path.abspath("extensions")
        if not os.path.exists(path):
            os.makedirs(path)
        if platform.system() == "Windows":
            os.startfile(path)
        elif platform.system() == "Darwin":  # macOS
            subprocess.Popen(["open", path])
        else:  # Linux
            subprocess.Popen(["xdg-open", path])

    def save_token(self):
        new_token = self.token_entry.get()
        if new_token:
            with open('token.env', 'w') as f:
                f.write(f"TOKEN={new_token}")
            messagebox.showinfo("Succès", "Token mis à jour. Redémarrez pour prendre effet.")
            self.token = new_token
        else:
            messagebox.showerror("Erreur", "Le token ne peut pas être vide.")

    def start_bot(self):
        if not self.token_entry.get():
            messagebox.showerror("Erreur", "Veuillez entrer un token valide.")
            return

        self.bot = create_bot_instance()

        loop = asyncio.new_event_loop()
        threading.Thread(target=self.run_asyncio_loop, args=(loop,), daemon=True).start()

        self.start_button.config(state="disabled")
        self.stop_button.config(state="normal")

    def run_asyncio_loop(self, loop):
        asyncio.set_event_loop(loop)
        self.bot.run(TOKEN)
        loop.run_forever()

    def stop_bot(self):
        if self.bot:
            asyncio.run_coroutine_threadsafe(self.bot.stop_bot(), asyncio.get_event_loop())
            self.start_button.config(state="normal")
            self.stop_button.config(state="disabled")

    def show_help(self):
        help_window = tk.Toplevel(self)
        help_window.title("Aide")
        help_window.geometry("500x400")

        help_text = scrolledtext.ScrolledText(help_window, wrap="word", bg="white", fg="black")
        help_text.pack(expand=True, fill="both", padx=10, pady=10)

        help_text.insert(tk.END,
        """Bienvenue dans le KairosCord Launcher !

- Entrez votre token Discord et cliquez sur 'Enregistrer le Token' pour le sauvegarder.
- Cliquez sur 'Démarrer le Bot' pour lancer votre bot Discord. Il est opérationel quand la console affiche que le bot a démarré.
- Cliquez sur 'Arrêter le Bot' pour stopper le bot.
- Si c'est votre premier lancement/si vous avez ajouté/supprimé une extension, faites !sync une fois votre bot démarré puis actualisez votre discord.
- Vous pouvez gérer les extensions (.py) du bot en ouvrant le dossier 'extensions'.

La console affichera les logs du bot en temps réel :
- Les erreurs s'affichent en rouge.
- Les messages normaux en blanc.

Bon usage ! 🎉
        """)

        help_text.configure(state="disabled")

    def on_close(self):
        if self.bot:
            asyncio.run_coroutine_threadsafe(self.bot.stop_bot(), asyncio.get_event_loop())
        self.destroy()

if __name__ == "__main__":
    app = BotLauncher()
    app.mainloop()