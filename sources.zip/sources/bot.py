import os
import discord
from discord.ext import commands
from dotenv import load_dotenv
from datetime import datetime
import asyncio
from extensions import *

load_dotenv('token.env')
TOKEN: str = os.getenv("TOKEN")

class KairosCord(commands.Bot):
	def __init__(self):
		super().__init__(command_prefix="!", intents=discord.Intents.all())
		self.token = TOKEN
		self.running_task = None

	from discord.app_commands.errors import CommandAlreadyRegistered

	async def setup_hook(self) -> None:

		for filename in os.listdir('./extensions'):
			if filename.endswith('.py'):
				cog_name = f"extensions.{filename[:-3]}"
				try:
					await self.load_extension(cog_name)
					print(f"{cog_name} chargé avec succès.")
				except Exception as e:
					print(f"Erreur lors du chargement de {cog_name}: {e}")

		await self.tree.sync()

	async def on_ready(self) -> None:
		now = datetime.now()
		current_time = now.strftime("%d/%m/%Y à %H:%M:%S")
		print(f'Le bot a démarré le {current_time}.')

	def run_bot(self):
		if self.running_task is None or self.running_task.done():
			self.running_task = asyncio.create_task(self.start(self.token))

	async def stop_bot(self):
		await self.close()

bot_instance = None

def create_bot_instance():
	global bot_instance
	bot_instance = KairosCord()

	@bot_instance.command(name="sync", help="Synchronise les commandes d'application avec Discord.")
	async def sync(ctx):
		synced = await bot_instance.tree.sync()
		await ctx.send(f"Synchronisation réussie ! {len(synced)} commande(s) enregistrée(s).")

	return bot_instance
